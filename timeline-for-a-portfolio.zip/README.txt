A Pen created at CodePen.io. You can find this one at http://codepen.io/armthethinker/pen/nEtke.

 A timeline inspired by http://kohlhofer.com/, built for a portfolio page.